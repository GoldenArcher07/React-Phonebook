import React from 'react';
import './Footer.css';


class Footer extends React.Component {

    constructor(props){
        super(props);

        this.state = {
            content: ""
        }

        this.state = {
            content2: ""
        }
        
        this.handleChange = this.handleChange.bind(this);
        this.handleChange2 = this.handleChange2.bind(this);
    }

    handleChange(event){
        this.setState({ content: event.target.value});
    }

    handleChange2(event2){
        this.setState({ content2: event2.target.value});
    }

    render() {
        return (<footer>
            <input value={this.state.content} onChange={this.handleChange} id="content" type="text" placeholder="Name:" />
            <input value={this.state.content2} onChange={this.handleChange2} id="content2" type="text" placeholder="Phone:" />
            <span id="add-btn" onClick={() => this.props.createItem(this.state.content, this.state.content2)}>Add</span>
        </footer>)

    }
}

export default Footer;
