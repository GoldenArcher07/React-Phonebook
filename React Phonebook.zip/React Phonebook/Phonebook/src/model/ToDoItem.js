
class ToDoItem {

    constructor(content, content2, date) {
        this.id = Math.random().toString(36).substring(7);
        this.content = content;
        this.content2 = content2;
        this.date = date;
        this.completed = false;
    }


    static fromJSON (json) {
        let toDoItem = new ToDoItem();
        toDoItem.id = json.id;
        toDoItem.content = json.content;
        toDoItem.content2 = json.content2;
        toDoItem.date = json.date;
        toDoItem.completed = json.completed;

        return toDoItem;
    }
}

export default ToDoItem;